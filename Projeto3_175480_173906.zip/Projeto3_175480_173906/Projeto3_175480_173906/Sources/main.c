/* ###################################################################
**     Filename    : main.c
**     Project     : Projeto3_175480_173906
**     Processor   : MKL25Z128VLK4
**     Version     : Driver 01.01
**     Compiler    : GNU C Compiler
**     Date/Time   : 2018-06-14, 01:35, # CodeGen: 0
**     Abstract    :
**         Main module.
**         This module contains user's application code.
**     Settings    :
**     Contents    :
**         No public methods
**
** ###################################################################*/
/*!
** @file main.c
** @version 01.01
** @brief
**         Main module.
**         This module contains user's application code.
*/         
/*!
**  @addtogroup main_module main module documentation
**  @{
*/         
/* MODULE main */


/* Including needed modules to compile this module/procedure */
#include "Cpu.h"
#include "Events.h"

#include "BitIoLdd2.h"
#include "Coluna2.h"
#include "BitIoLdd3.h"
#include "Coluna3.h"
#include "BitIoLdd1.h"
#include "MCUC1.h"
#include "Coluna1.h"
#include "WAIT1.h"
#include "PDC1.h"
#include "RESpin1.h"
#include "SCEpin1.h"
#include "D_Cpin1.h"
#include "SM1.h"
#include "AS1.h"
#include "ASerialLdd1.h"
#include "AD1.h"
#include "AdcLdd1.h"
#include "EE241.h"
#include "GI2C1.h"
#include "CI2C1.h"
#include "UTIL1.h"
#include "TI1.h"
#include "TimerIntLdd1.h"
#include "TU1.h"
#include "Linha1.h"
#include "ExtIntLdd1.h"
#include "Linha2.h"
#include "ExtIntLdd2.h"
#include "Linha3.h"
#include "ExtIntLdd3.h"
#include "Linha4.h"
#include "ExtIntLdd4.h"
/* Including shared modules, which are used for whole project */
#include "PE_Types.h"
#include "PE_Error.h"
#include "PE_Const.h"
#include "IO_Map.h"

/* User includes (#include below this line is not maintained by Processor Expert) */

#define TAMANHO_BUFFER_EEPROM 16//Determina quantas amostras ser�o guardadas no buffer da RAM antes de guard�-las na EEPROM de fato. 
#define ID 2422//Apenas um numero de identifica��o para este dispositivo.
#define BUFFER_STRINGS 64//Este ser� o tamanho de eventuais strings usadas meramente como buffers.


volatile int tecla;//Esta vari�vel � respons�vel por receber o resultado da varredura do teclado nas interrup��es.
volatile long hora_de_amostrar;//Flag setada na interrup��o do timer 1 quando for hora de colher nova amostra de temperatura. Vale 1 se estiver na hora e 0 se n�o.

void desligaColunas(){//Uma fun��o compacta para colocar n�vel baixo em todos os GPIO ligados �s colunas do teclado.
	Coluna3_ClrVal();
	Coluna2_ClrVal();
	Coluna1_ClrVal();
}

int linha4_OnInterruptReturn(void){
	int tecla = -1;//Uma vari�vel local para calcularmos o vaor da tecla real pressioanda
	
	WAIT1_Waitms(10);//Tempo para aguardar o debouncing por capacitor.
	
	Coluna1_SetVal(); 
	WAIT1_Waitms(10);
	if(Linha4_GetVal()){//Se a mudan�a para nivel alto da coluna 1 fizer a linha 4 se ativar, 
		desligaColunas();
		tecla = 10;//significa que era a tecla # que estava pressionada (pois � a interse��o destas retas).
		return tecla;//Agora que j� executamos a varredura e encontramos a tecla de origem do sinal, setamos em LOW as colunas e retornamos o valor correpondente � tecla encontrada.//Agora que j� executamos a varredura e encontramos a tecla de origem do sinal, setamos em LOW as colunas e retornamos o valor correpondente � tecla encontrada.
	}
	
	Coluna2_SetVal(); 
	WAIT1_Waitms(10);//Tempo para aguardar a carga do capacitor.
	if(Linha4_GetVal()){//Se a mudan�a para nivel alto da coluna 2 fizer a linha 4 se ativar, 
		desligaColunas();
		tecla = 0;//significa que era a tecla 0 que estava pressionada (pois � a interse��o destas retas).
		return tecla;//Agora que j� executamos a varredura e encontramos a tecla de origem do sinal, setamos em LOW as colunas e retornamos o valor correpondente � tecla encontrada.
	}
	
	Coluna3_SetVal(); 
	WAIT1_Waitms(11);//Tempo para aguardar a carga do capacitor.
	if(Linha4_GetVal()){//Se a mudan�a para nivel alto da coluna 3 fizer a linha 4 se ativar, 
		desligaColunas();
		tecla = 10;//significa que era a tecla * que estava pressionada (pois � a interse��o destas retas).
		return tecla;//Agora que j� executamos a varredura e encontramos a tecla de origem do sinal, setamos em LOW as colunas e retornamos o valor correpondente � tecla encontrada.
	}
	
	//Retornando as colunas para seus valores em n�vel baixo para receber as pr�ximas interrup��es.
	desligaColunas();
	WAIT1_Waitms(10);//Espera o capacitor se carregar com o atual valor de tens�o.
	
	return tecla;	
}

int linha3_OnInterruptReturn(void){
	int tecla = -1;//Uma vari�vel local para calcularmos o vaor da tecla real pressioanda
	
	WAIT1_Waitms(10);//Tempo para aguardar o debouncing por capacitor.
	
	Coluna1_SetVal(); 
	WAIT1_Waitms(10);//Tempo para aguardar a carga do capacitor.
	if(Linha3_GetVal()){//Se a mudan�a para nivel alto da coluna 1 fizer a linha 3 se ativar, 
		desligaColunas();
		tecla = 7;//significa que era a tecla 7 que estava pressionada (pois � a interse��o destas retas).
		return tecla;//Agora que j� executamos a varredura e encontramos a tecla de origem do sinal, setamos em LOW as colunas e retornamos o valor correpondente � tecla encontrada.
	}
	
	Coluna2_SetVal(); 
	WAIT1_Waitms(10);//Tempo para aguardar a carga do capacitor.
	if(Linha3_GetVal()){//Se a mudan�a para nivel alto da coluna 2 fizer a linha 3 se ativar, 
		desligaColunas();
		tecla = 8;//significa que era a tecla 8 que estava pressionada (pois � a interse��o destas retas).
		return tecla;//Agora que j� executamos a varredura e encontramos a tecla de origem do sinal, setamos em LOW as colunas e retornamos o valor correpondente � tecla encontrada.
	}
	
	Coluna3_SetVal(); 
	WAIT1_Waitms(10);//Tempo para aguardar a carga do capacitor.
	if(Linha3_GetVal()){//Se a mudan�a para nivel alto da coluna 3 fizer a linha 3 se ativar, 
		desligaColunas();
		tecla = 9;//significa que era a tecla 9 que estava pressionada (pois � a interse��o destas retas).
		return tecla;//Agora que j� executamos a varredura e encontramos a tecla de origem do sinal, setamos em LOW as colunas e retornamos o valor correpondente � tecla encontrada.
	}
	
	//Retornando as colunas para seus valores em n�vel baixo para receber as pr�ximas interrup��es.
	desligaColunas();
	WAIT1_Waitms(10);//Espera o capacitor se carregar com o atual valor de tens�o.
	
	return tecla;
}

int linha2_OnInterruptReturn(void){
	int tecla = -1;//Uma vari�vel local para calcularmos o vaor da tecla real pressioanda
	
	WAIT1_Waitms(10);//Tempo para aguardar o debouncing por capacitor.
	
	Coluna1_SetVal(); 
	WAIT1_Waitms(10);//Tempo para aguardar a carga do capacitor.
	if(Linha2_GetVal()){//Se a mudan�a para nivel alto da coluna 1 fizer a linha 2 se ativar, 
		desligaColunas();
		tecla = 4;//significa que era a tecla 4 que estava pressionada (pois � a interse��o destas retas).
		return tecla;//Agora que j� executamos a varredura e encontramos a tecla de origem do sinal, setamos em LOW as colunas e retornamos o valor correpondente � tecla encontrada.
	}
	
	Coluna2_SetVal(); 
	WAIT1_Waitms(10);//Tempo para aguardar a carga do capacitor.
	if(Linha2_GetVal()){//Se a mudan�a para nivel alto da coluna 2 fizer a linha 2 se ativar, 
		desligaColunas();
		tecla = 5;//significa que era a tecla 5 que estava pressionada (pois � a interse��o destas retas).
		return tecla;//Agora que j� executamos a varredura e encontramos a tecla de origem do sinal, setamos em LOW as colunas e retornamos o valor correpondente � tecla encontrada.
	}
	
	Coluna3_SetVal(); 
	WAIT1_Waitms(10);//Tempo para aguardar a carga do capacitor.
	if(Linha2_GetVal()){//Se a mudan�a para nivel alto da coluna 3 fizer a linha 2 se ativar, 
		desligaColunas();
		tecla = 6;//significa que era a tecla 6 que estava pressionada (pois � a interse��o destas retas).
		return tecla;//Agora que j� executamos a varredura e encontramos a tecla de origem do sinal, setamos em LOW as colunas e retornamos o valor correpondente � tecla encontrada.
	}
	
	//Retornando as colunas para seus valores em n�vel baixo para receber as pr�ximas interrup��es.
	desligaColunas();
	WAIT1_Waitms(10);//Espera o capacitor se carregar com o atual valor de tens�o.
	
	return tecla;
}

int linha1_OnInterruptReturn(void){
	int tecla = -1;//Uma vari�vel local para calcularmos o vaor da tecla real pressioanda
	
	WAIT1_Waitms(10);//Tempo para aguardar o debouncing por capacitor.
	
	Coluna1_SetVal(); 
	WAIT1_Waitms(10);//Tempo para aguardar a carga do capacitor.
	if(Linha1_GetVal()){//Se a mudan�a para nivel alto da coluna 1 fizer a linha 1 se ativar, 
		desligaColunas();
		tecla = 1;//significa que era a tecla 1 que estava pressionada (pois � a interse��o destas retas).
		return tecla;//Agora que j� executamos a varredura e encontramos a tecla de origem do sinal, setamos em LOW as colunas e retornamos o valor correpondente � tecla encontrada.
	}
	
	Coluna2_SetVal(); 
	WAIT1_Waitms(10);//Tempo para aguardar a carga do capacitor.
	if(Linha1_GetVal()){//Se a mudan�a para nivel alto da coluna 2 fizer a linha 1 se ativar, 
		desligaColunas();
		tecla = 2;//significa que era a tecla 2 que estava pressionada (pois � a interse��o destas retas).
		return tecla;//Agora que j� executamos a varredura e encontramos a tecla de origem do sinal, setamos em LOW as colunas e retornamos o valor correpondente � tecla encontrada.
	}
	
	Coluna3_SetVal(); 
	WAIT1_Waitms(10);//Tempo para aguardar a carga do capacitor.
	if(Linha1_GetVal()){//Se a mudan�a para nivel alto da coluna 3 fizer a linha 1 se ativar, 
		desligaColunas();
		tecla = 3;//significa que era a tecla 3 que estava pressionada (pois � a interse��o destas retas).
		return tecla;//Agora que j� executamos a varredura e encontramos a tecla de origem do sinal, setamos em LOW as colunas e retornamos o valor correpondente � tecla encontrada.
	}
	
	//Retornando as colunas para seus valores em n�vel baixo para receber as pr�ximas interrup��es.
	desligaColunas();	
	WAIT1_Waitms(10);//Espera o capacitor se carregar com o atual valor de tens�o.
}


/*lint -save  -e970 Disable MISRA rule (6.3) checking. */
int main(void)
/*lint -restore Enable MISRA rule (6.3) checking. */
{
  /* Write your local variable definition here */

	
	
	
	tecla = -1;
	int aux = 0;//vari�vel auxiliar gen�rica para qualquer opera��o que precise guardar um valor temporario.
	int tecla_anterior = -1;//Quando pressionarem a tecla # para confirmar o comando, precisaremos qual a tecla q tinha sido
							//pressionada anteriormente para sabermos qual era o comando.
	
	/* ADC resulta valores de 0 a 0xFFFF.*/
	int v_temperatura;//A tens�o lida no sensor de temperatura LM61 pelo ADC.
	v_temperatura = 0;//PRECISA SER INICIADO EM ZERO. O ADC N�O ZERA OS BITS QUANDO VAI CONVERTER, SE HOUVER O BIT DE SINAL NEGATIVO, ELE FICA SALVO NELA E SEUS VALORES SERAO NEGATIVOS ( TIPO O COMPLEMENTO DE 2).
	int temperatura_dCelsius = 0;
	hora_de_amostrar = 0;
	
	char string_aux[BUFFER_STRINGS] = "String AUXILIAR para ajudar em convers�es";
	
	/*Variaveis para EEPROM*/
	char buffer_RAM[2*TAMANHO_BUFFER_EEPROM];//Buffer que guardar� temporariamente os dados a serem encaminhadoa para a EEPROM. Os dados s�o alocados de dois em dois Bytes, por isso a multiplica��o por 2.
	int contadorBitMaior = 0;//Mantemos a contagem de quantos dados foram escritos por dois bits de pagina��o
	int contadorBitMenor = 0;
	int contadorBitMaiorEEPROM = 0;//Os dados na EEPROM s� s�o escritos a cada 16 amostras, ent�o eles estar�o, geralmente, um pouco defasados.
	int contadorBitMenorEEPROM = 0;
	
  /*** Processor Expert internal initialization. DON'T REMOVE THIS CODE!!! ***/
  PE_low_level_init();
  /*** End of Processor Expert internal initialization.                    ***/

  /* Write your code here */
  
	PDC1_Clear();
	WAIT1_Waitms(10);
	PDC1_WriteLineStr(1, "AguardaComando\n");
	
	desligaColunas();
	WAIT1_Waitms(10);//Espera o capacitor se carregar com o atual valor de tens�o.
	
	while(1){//Este loop infinito � onde se executa o algoritmo que rege o sistema at� o final.
	
	  /*
	   * A vari�vel "aux" � IMPRESCINDIVEL para o funcionamento do programa. A interrup��o pode ocorrer a qualquer momento, e a l�gica do script sup�e que
	   * estamos lidando com um mesmo valor de tecla ao longo de cada loop completo. Por isso, salvamos o valor da "tecla" em aux logo no in�cio do loop while
	   * e o tramos ao longo do script.
	   * Ao final de cada loop, atualizaremos para um poss�vel novo valor de tecla.
	   */
	  aux=tecla;
	  
	  if(aux != -1){//Se a tecla vale -1, todas as a��es tom�veis do momento j� foram realizadas e estaremos apenas aguardando.
		  
//====================IDENTIFICACAO DO COMANDO DE TECLADO============================================================================================================================
		  /*
		   * Os n�meros do teclado variam s� de 0 a 9, mas para reprensetar os caracteres especiais podemos simplesmente escolher valores
		   * inteiros com mais de um d�gito (para na se confundir com os n�meros de verdade).
		   * 
		   * Tecla 10 representa #
		   * Tecla 11 representa *
		   */
		  
		  if(aux == 10){//Se houvermos recebido asterisco * como entrada, devemos cancelar o comando limpando seu registro.
			tecla = tecla_anterior = -1;
			PDC1_Clear();
			WAIT1_Waitms(10);
			PDC1_WriteLineStr(1, "AguardaComando\n");
			  
		  }//Repare que aux s� � atualizado no "if" abaixo, mas estamos dentro de um loop infinito, ent�o voltaremos aqui em breve para a verifica��o.
		  //O motivo de usar a vari�vel auxiliar � devido ao fato que a interrup��o pode ocorrer a qualquer momento, e queremos utilizar o valor uqe !tecla! possuia no momento da verifica��o da condi��o do "if" abaixo.
		  
		  if(aux!=-1){//Esta condi��o j� foi verificada para chegar at� aqui, mas � s� mais uma garantia de que esta vari�vel s� guardar� o valor das teclas anteriormente pressionadas.
			tecla_anterior = aux;
			/*
			 * � importante salvar em aux antes de salvar o valor, pois se a interrup��o alterar o valor de tecla para uma # 
			 * antes de detectarmos isso, poder�amos sobrescrever o valor da tecla anterior com # e perder a info do comando dado.
			 */
		  }
		  
		  //Quando j� identificamos que uma linha foi ativada mas n�o sabemos qual coluna (ou tecla) especificamente foi, aux = tecla possui um valor acima de 100 e n�o deve ser tratado aqui.
		  if(aux == 11 && aux < 100){//Se a tecla pessionada atualmente n�o for # (confirma��o de comando), salve a info da ultima tecla pressionada.
			  tecla = -1;//J� salvamos o valor da �ltima tecla pressionada, agora resetamos esta vari�vel para n�o ficar entrando neste "if" acima e reescrevendo o display toda hora.
			  
	
			  
			  switch(tecla_anterior){//Tomaremos a a��o de acordo com a tecla que foi pressionda
					  
				  case 1://Reset: Apaga toda a mem�ria, com aviso no display
					  PDC1_Clear();
					  WAIT1_Waitms(10);
					  PDC1_WriteLineStr(1, "Memoria Apagada\n");
					  break;
					  
				  case 2://ID: Apresenta no display a string de identifica��o
					  PDC1_Clear();
					  PDC1_WriteLineStr(1, "ID:\n");
					  UTIL1_Num16sToStr(string_aux,BUFFER_STRINGS, ID);
					  PDC1_WriteLineStr(2, string_aux);
					  break;
					  
				  case 3://Measure: Apresenta no display o valor de temperatura, sem gravar
					  PDC1_Clear();
					  AD1_GetValue16(&v_temperatura);//Atualizamos o valor de temperatura atual.
					  UTIL1_Num16sToStr(string_aux,BUFFER_STRINGS, v_temperatura);
					  PDC1_WriteLineStr(1, string_aux);
					  break;
					  
				  case 4://Status: Mostra no display o n�mero de dados gravados e o n�mero de medi��es dispon�veis
					  PDC1_Clear();
					  
					  PDC1_WriteLineStr(1, "Dados Gravados\n");
					  aux =  2*(256*contadorBitMaiorEEPROM + contadorBitMenorEEPROM);//Calculamos quantos dados est�o gravados na EEPROM.
					  UTIL1_Num16sToStr(string_aux,BUFFER_STRINGS, aux);
					  PDC1_WriteLineStr(2, string_aux);
					  
					  PDC1_WriteLineStr(3, "Dados Disponiveis\n");
					  aux =  2*(256*contadorBitMaior + contadorBitMenor);//Calculamos quantos dados est�o gravados na RAM (deve ter alguns que ainda n�o foram para a EEPROM, pis s� v�o a cada 16 coletas).
					  UTIL1_Num16sToStr(string_aux,BUFFER_STRINGS, aux);
					  PDC1_WriteLineStr(4, string_aux);
					  
					  break;
					  
				  case 5://Inicia coleta peri�dica: Mostra mensagem no display
								  
					  break;
		
				  case 6://Finaliza coleta peri�dica: Mostra mensagem no display
					  
					  break;
					  
				  case 7://Dump de dados: Envia pela porta serial os dados coletados, aviso no display. O dump deve enviar as medidas de temperatura separadas por quebras de linha (CR + LF).
								  
					  break;
					  
				  default:
					  
					  break;
	
			  }
			  
			  
		  }else if(aux < 100){//Se a tecla atual pressionada foi realmente #, execute o comando
			  
			  switch(tecla_anterior){//Tomaremos a a��o de acordo com a tecla que foi pressionda
			  
				  case 1://Reset: Apaga toda a mem�ria, com aviso no display
					  PDC1_Clear();
					  WAIT1_Waitms(10);
					  PDC1_WriteLineStr(1, "Memoria Apagada\n");
					  break;
					  
				  case 2://ID: Apresenta no display a string de identifica��o
					  PDC1_Clear();
					  PDC1_WriteLineStr(1, "ID:\n");
					  UTIL1_Num16sToStr(string_aux,BUFFER_STRINGS, ID);
					  PDC1_WriteLineStr(2, string_aux);
					  break;
					  
				  case 3://Measure: Apresenta no display o valor de temperatura, sem gravar
					  PDC1_Clear();
					  AD1_GetValue16(&v_temperatura);//Atualizamos o valor de temperatura atual.
					  UTIL1_Num16sToStr(string_aux,BUFFER_STRINGS, v_temperatura);
					  PDC1_WriteLineStr(1, string_aux);
					  break;
					  
				  case 4://Status: Mostra no display o n�mero de dados gravados e o n�mero de medi��es dispon�veis
					  PDC1_Clear();
					  
					  PDC1_WriteLineStr(1, "Dados Gravados\n");
					  aux =  2*(256*contadorBitMaiorEEPROM + contadorBitMenorEEPROM);//Calculamos quantos dados est�o gravados na EEPROM.
					  UTIL1_Num16sToStr(string_aux,BUFFER_STRINGS, aux);
					  PDC1_WriteLineStr(2, string_aux);
					  
					  PDC1_WriteLineStr(3, "Dados Disponiveis\n");
					  aux =  2*(256*contadorBitMaior + contadorBitMenor);//Calculamos quantos dados est�o gravados na RAM (deve ter alguns que ainda n�o foram para a EEPROM, pis s� v�o a cada 16 coletas).
					  UTIL1_Num16sToStr(string_aux,BUFFER_STRINGS, aux);
					  PDC1_WriteLineStr(4, string_aux);
					  
					  break;
					  
				  case 5://Inicia coleta peri�dica: Mostra mensagem no display
					  PDC1_Clear();
					  WAIT1_Waitms(10);
					  PDC1_WriteLineStr(1, "Coleta Iniciada\n");
					  break;
		
				  case 6://Finaliza coleta peri�dica: Mostra mensagem no display
					  PDC1_Clear();
					  WAIT1_Waitms(10);
					  PDC1_WriteLineStr(1, "Coleta Finalizada\n");
					  break;
					  
				  case 7://Dump de dados: Envia pela porta serial os dados coletados, aviso no display. O dump deve enviar as medidas de temperatura separadas por quebras de linha (CR + LF).
					  PDC1_Clear();
					  WAIT1_Waitms(10);
					  PDC1_WriteLineStr(1, "Dump de Dados\n");
					  break;
					  
				  default:
					  
					  break;
			  }
			  
			  tecla = -1;//Reiniciamos os valores das vari�veis.
			  
		  }
//====================FIM DA IDENTIFICACAO DO COMANDO DE TECLADO============================================================================================================================
		  
//====================VARREDURA DO TECLADO============================================================================================================================	  
		  /*
		   * Convencionou-se que as fun��es de tratamento de interrup��o retornar�o valores m�ltiplos de 100 para identificar que alguma linha do teclado foi acionada.
		   * Para a linha 3, por exemplo, ser� retornado o valor 300 em "tecla". Para a linha 4, 400.
		   * Depois de recebe este valor, executaremos uma r�pida varredura do teclado para identificar qual coluna, e tamb�m a tecla espec�fica, por conseguinte, originou a interrup��o.
		   */
		  
		  
		  if(aux >= 100){
			  switch(aux){//Tomaremos a a��o de acordo com a tecla que foi pressionda
					  
				case 100://Interrup��o gerada na linha 1 do teclado matricial
				  tecla = linha1_OnInterruptReturn();//Agora que executamos a varredura e sabemos qual a tecla que foi pressionada, atualizemos o seu valor
				  break;
				  
				case 200://Interrup��o gerada na linha 2 do teclado matricial
					tecla = linha2_OnInterruptReturn();//Agora que executamos a varredura e sabemos qual a tecla que foi pressionada, atualizemos o seu valor
					break;
				  
				case 300://Interrup��o gerada na linha 3 do teclado matricial
				  tecla = linha3_OnInterruptReturn();//Agora que executamos a varredura e sabemos qual a tecla que foi pressionada, atualizemos o seu valor
				  break;
				  
				case 400://Interrup��o gerada na linha 4 do teclado matricial
				  tecla = linha4_OnInterruptReturn();//Agora que executamos a varredura e sabemos qual a tecla que foi pressionada, atualizemos o seu valor
				  break;
				  
				default:
				  break;
			  }
		  }
		  
//====================FIM DA VARREDURA DO TECLADO============================================================================================================================
		  
	  }
	  
//====================LEITURA DA TEMPERATURA E GRAVACAO NA EEPROM============================================================================================================================

	  if(hora_de_amostrar == 1){//Esta condicao nos permite ler a temperatura somente quando for a hora de colher nova amostra.
		  
		  /* ADC resulta valores de 0 a 0xFFFF.*/
		  
		  AD1_Measure(1);//Manda fazer uma conversao e aguarda (1) o resultado.
		  while(AD1_GetValue16(&v_temperatura) == ERR_NOTAVAIL);//Aguarda atualizarmos o valor de temperatura atual.
		  v_temperatura = v_temperatura * 3300 / 0xFFFF;//j� convertemos o valor lido para o valor em tens�o (milivolts - 3.3V neste microcontrolador).
		  hora_de_amostrar = 0;//J� amostramos a temperatura, ent�o devemos aguardar at� chegar o momento novamente. A interrup��o seta a flag a cada 2 segundos.
		  temperatura_dCelsius = v_temperatura - 600;//O sensor de temperatura nos fornece esta em decigraus Celsius somada a 600mV.
		  
		  
		  
		//EE241_WriteBlock( 2*((256*contadorBitMaiorEEPROM) +  contadorBitMenorEEPROM) + 1, test1, 16);
		//EE241_ReadBlock(0x00, rcv, 32);
	  }

//====================FIM DA LEITURA DA TEMPERATURA E GRAVACAO NA EEPROM============================================================================================================================
	  
}
  
  
  /* For example: for(;;) { } */

  /*** Don't write any code pass this line, or it will be deleted during code generation. ***/
  /*** RTOS startup code. Macro PEX_RTOS_START is defined by the RTOS component. DON'T MODIFY THIS CODE!!! ***/
  #ifdef PEX_RTOS_START
    PEX_RTOS_START();                  /* Startup of the selected RTOS. Macro is defined by the RTOS component. */
  #endif
  /*** End of RTOS startup code.  ***/
  /*** Processor Expert end of main routine. DON'T MODIFY THIS CODE!!! ***/
  for(;;){}
  /*** Processor Expert end of main routine. DON'T WRITE CODE BELOW!!! ***/
} /*** End of main routine. DO NOT MODIFY THIS TEXT!!! ***/

/* END main */
/*!
** @}
*/
/*
** ###################################################################
**
**     This file was created by Processor Expert 10.3 [05.09]
**     for the Freescale Kinetis series of microcontrollers.
**
** ###################################################################
*/
