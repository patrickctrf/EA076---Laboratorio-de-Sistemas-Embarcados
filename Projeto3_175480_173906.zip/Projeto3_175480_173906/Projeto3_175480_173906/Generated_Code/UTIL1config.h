#ifndef __UTIL1_CONFIG_H
#define __UTIL1_CONFIG_H

/* no configuration supported yet */

#endif /* __UTIL1_CONFIG_H */
